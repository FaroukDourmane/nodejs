const users = ["Farouk","Jack","John"];
console.log(users);